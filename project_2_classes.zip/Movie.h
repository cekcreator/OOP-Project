//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 pt1 problem 1

#include <iostream>
#include <fstream>
#ifndef MOVIE_H
#define MOVIE_H
using namespace std;

class Movie  // class containg the member functions for moive class 
{
    public: // constructors
        Movie();
        Movie( string _title, string _ReleaseYear); // constrcutors for the moive 
        // getters 
        string getTitle();              //getting title of movie 
        string getReleaseYear();        // getting release of mvie 
        //setters
        void setTitle( string _title);                  // setters getting  the title and release year after they are stored 
        void setReleaseYear( string _releaseYear);
        
    private: 
        string title;               // private functions not moving 
        string releaseYear;
         
};

#endif