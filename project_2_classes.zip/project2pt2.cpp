//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 problem 9

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include "Movie.h"
#include "User.h"
#include "BlockBustr.h"

using namespace std;

int main()
{
    int userNum = 0; // variables for keeping track of the number of users  and movies stored in the system 
    int movieNum = 0;
    bool done = false; // bool varaible for the menu loop 
    int x = 0;
    int val = 0;            // val variable for each function 
    string filename;        // string varables for user inputs 
    string year;
    string username;
    string title; 
    double newRating = 0.00;        // for the new rating needs to be double 
    double addRate = 0.00;
    Blockbustr blockbustr;          // creating the instance for blockbustr for each function 
    while(!done)
    {
        cout << "======Main Menu=====" << endl;             // menu read out to the user 
        cout << "1. Read movies " << endl;
        cout << "2. Read ratings" << endl; 
        cout << "3. Print movies by year" << endl;
        cout << "4. Get rating" << endl;
        cout << "5. Find number of movies user rated" << endl;
        cout << "6. Get average rating" << endl;
        cout << "7. Add a user" << endl; 
        cout << "8. Rent a movie" << endl; 
        cout << "9. Quit" << endl;
        cin >> x;
        cin.ignore();
        switch(x)
        {
            case 1: 
                cout << "Enter a movie file name:" << endl; 
                getline(cin, filename);
                val = blockbustr.readMovies(filename);
                if ( val > 0 )                                  // count tracking the num movies added 
                {
                    movieNum = val; 
                }
                if (val == -2)                                  // options for what the function returns readiong out to the user 
                {
                    cout << "Database is already full. No movies were added." << endl; 
                }
                else if ( val == -1)
                {
                    cout << "No movies saved to the database." << endl; 
                }
                else if ( val == 50 )
                {
                    cout << "Database is full. Some movies may have not been added." << endl; 
                }
                else if ( val >= 0 && val < 50)
                {
                    cout << "Total movies in the database: " << val << endl; 
                }
                break; 
            
            case 2:                                                 // reading the ratins from a user file 
                cout << "Enter a user file name:" << endl; 
                getline(cin, filename);
                val = blockbustr.readRatings(filename);             // using the return value from the function 
                if ( val > 0)
                {
                    userNum = val;
                }
                if (val == -2)                                        // reading out the return option to users 
                {
                    cout << "Database is already full. No users were added." << endl; 
                }
                else if ( val == -1)
                {
                    cout << "No users saved to the database." << endl; 
                }
                else if (val == 100)
                {
                    cout << "Database is full. Some users may have not been added." << endl; 
                }
                else if (val >= 0 && val < 100)
                {
                    cout << "Total users in the database: " << val << endl; 
                }
                break; 
            
            case 3:                                             // getting in the year and print out the movies is the apart of the year 
                if ( movieNum == 0 || userNum == 0)
                {
                    cout << "Database has not been fully initialized." << endl;         // checking to see if the dmovie and user arrays exist 
                }
                else 
                {
                    cout << "Enter release year of movie:" << endl; 
                    getline(cin, year);
                    blockbustr.printMoviesByYear(year);
                }
                break; 
            
            case 4:                                             // get rating of a movie 
                if ( movieNum == 0 || userNum == 0)
                {
                    cout << "Database has not been fully initialized." << endl;    // checking to see if the dmovie and user arrays exist
                }
                else 
                {
                    cout << "Enter a user name: " << endl;                  // taking in user input 
                    getline(cin, username);
                    cout << "Enter a movie title: " << endl;
                    getline(cin, title);
                    val = blockbustr.getRating(username, title);
                    if ( val == -3)                                                         //returnign the value and reading out to user 
                    {
                        cout << username << " or " << title << " does not exist." << endl; 
                    }
                    else if (val == 0 )
                    {
                        cout << username << " has not rated " << title << endl; 
                    }
                    else 
                    {
                        cout << username << " rated " << title << " with " << val << endl; 
                    }
                }
                break; 
            
            case 5:                                                     //getting number of movies rated by a user 
                if (  movieNum == 0 || userNum == 0)
                {
                    cout << "Database has not been fully initialized." << endl;  // checking to see if the dmovie and user arrays exist
                }
                else 
                {
                    cout << "Enter a user name: " << endl;
                    getline(cin, username);   
                    val = blockbustr.getCountWatchedMovies(username);
                    if (val == -3)                                                      //checks for if username exits, if they have rated any movies, then reads out username and their number of rated movies 
                    {
                        cout << username << " does not exist." << endl; 
                    }
                    else if (val == 0)
                    {
                        cout << username << " has not rated any movies." << endl; 
                    }
                    else
                    {
                        cout << username << " rated " << val << " movies." << endl; 
                    }
                }
                break; 
            
            case 6:
                if ( movieNum == 0 || userNum == 0)
                {
                    cout << "Database has not been fully initialized." << endl;      // checking to see if the dmovie and user arrays exist
                }
                else 
                {
                    cout << "Enter a movie title: " << endl; 
                    getline(cin, title);
                    addRate = blockbustr.calcAvgRating(title);              // getting the average rating of a moive given in by the user, checks to see if the moive exists first 
                    if (addRate == -3)
                    {
                        cout << title << " does not exist." << endl; 
                    }
                    else 
                    {
                        cout << "The average rating for " << title << " is " << fixed << setprecision(2) << addRate << endl; 
                    }
                }
                break; 
            
            case 7: 
                cout << "Enter a user name: " << endl;
                getline(cin, username); 
                val = blockbustr.addUser(username);                         // adding user to the user array 
                if ( val == -2) 
                {
                    cout << "Database is already full. " << username << " was not added." << endl; 
                }
                else if (val == 1)                                          // adds the iuser succsefuuly or checks if they already exist
                {
                    cout << "Welcome to Blockbustr " << username << endl;
                    userNum++;
                }
                else if ( val == 0 )
                {
                    cout << username << " already exists in the database." << endl; 
                }
                break;
            
            case 8:                                             //renting a moive and taking in a new rating 
                if ( movieNum ==0 || userNum == 0)
                {
                    cout << "Database has not been fully initialized." << endl;     // checking to see if the dmovie and user arrays exist
                }
                else 
                {
                    cout << "Enter a user name: " << endl;
                    getline(cin, username);
                    cout << "Enter a movie title: " << endl; 
                    getline(cin, title);
                    cout << "Enter a new rating: " << endl; 
                    cin >> newRating; 
                    val = blockbustr.rentMovie(username, title, newRating);         // getting the value and taking in the new rating 
                    if (val == -4) 
                    {
                        cout << newRating << " is not valid." << endl; 
                    }
                    else if ( val == -3)
                    {
                        cout << username << " or " << title << " does not exist." << endl;      // cehcking for existing options
                    }
                    else if ( val == 1)
                    {
                        cout << "We hope you enjoyed your movie. The rating has been updated." << endl;         /// everything worked 
                    }
                }
                break;
            
            case 9:
                cout << "Good bye!" << endl;            // menu quit option 
                done = true; 
                return 0;
                break; 
            
            default :
                cout << "Invalid input." << endl;       // default statement for input validation 
                break;
        }
    }
}