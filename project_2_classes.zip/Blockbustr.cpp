//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 problem 1

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include "BlockBustr.h"

using namespace std ; 

/**
 * tolower takes in a string and returns the string in all lower case letters
 * uses the string and ascii values to look for the uppercase  
 */
string ToLower(string str)
{
    string tempS = "";
    for (int i = 0; i < str.length(); i++ )
    {
        if (str[i] >= 65 && str[i] <= 90) // checks for upper case 
        {
           tempS += str[i] + 32; // converts to lowercase 
        } 
        else 
        {
            tempS += str[i];        // keeps rest of string 
        }
    }
    return tempS;
}

/**
 * takes user input string to split up by given dellimeters
 * takes in all user inputs and runs them through this function 
 * if string has no length it does nothing if not it goes through and separates the string by the delimiter
 */
int split(string inputString, char separator, string arr[], int size)
{
    for ( int i = 0; i < size; i++)
    {
        arr[i] = "";
    }
    if( inputString.length() == 0) // input validation statemnent 
    {
        return 0;
    }
    int index = 0;                  
    for (unsigned int i = 0; i < inputString.length(); i++)          // for loop loops through the string entered and validates the string
    {
        if ( index == size)     // if the 
        {
            return -1; 
        }
        else 
        {
            if ( inputString[i] == separator)       // this set of statements checks the location of separator and then separates the strings and stores them 
            {
                index++;
            }
            else 
            {
               arr[index] += inputString[i];  // separates the string 
            }
        }
    }
    return index + 1;
}

// initalizes variables to 0
Blockbustr::Blockbustr()
{
    _numMovies = 0;
    _numUsers = 0; 
}

// returns the sze of the movie array 
int Blockbustr::getSizeMovie()
{
    return _sizeMovie; 
}

// returns the size of the user array 
int Blockbustr::getSizeUser()
{
    return _sizeUser;
}

//returns the number movies currently
int Blockbustr::getNumMovies()
{
    return _numMovies;
}

// returns number of users currently 
int Blockbustr::getNumUsers()
{
    return _numUsers; 
}

// reads movies from files and gets the number of movies 
int Blockbustr::readMovies(string filename)
{
    int count = _numMovies;
    string placeholder;
    string line; 
    string array[2];
    ifstream fin; 
    fin.open(filename);
    if (_numMovies == _sizeMovie)        // checks if array is full 

    {
        return -2; 
    }
    if (fin.fail())     // checks if the file opens 
    {
        return -1; 
    }
    while (!fin.eof() && _numMovies - 1 < _sizeMovie)        // reads only if theres stuff in file anf the array sizes work out 
    {
        getline(fin , line);
        int splits = split(line , ',', array, 2);
        if(line.length() > 1 && !isspace(line[0]))
        {
            if( splits == 2)                                // if split is correct and movie and year are separated the 
            {
                movieArr[count] = Movie();
                movieArr[count].setTitle(array[0]);
                movieArr[count].setReleaseYear(array[1]);             // these two store the values in the arrays
                _numMovies++;
                count++;
            }
        }
    }
    return count;
}

// prints movies by year given from user input 
void Blockbustr::printMoviesByYear(string year)
{
    string matchArr[100]; 
    string line ="";
    int numMatch = 0;
    if (_numMovies <= 0)
    {
        cout <<"No movies are stored" << endl;      // checks for movies stored == 0 
    }
    else
    {
        for (int i = 0; i < _numMovies; i++)
        {
            if(movieArr[i].getReleaseYear() == year)
            {
                matchArr[numMatch] = movieArr[i].getTitle();          // counts the number moives with the wanted release year 
                numMatch++;
            }
        }
        if (numMatch > 0) 
        {
            cout << "Here is a list of movies released in " << year << endl;
            for ( int j = 0; j < numMatch; j++)
            {
                cout << matchArr[j] << endl;        // prints out all the moives of wanted release
            }
        }
        else 
        {
            cout << "There are no stored movies released in " << year << endl; 
        }
    
    }
}

// reads the ratings given from a file and returns the numbe of ratings from a specific user 
int Blockbustr::readRatings(string filename)
{
    string line; 
    ifstream fin;
    User line1;
    int count = 0;
    int userCount = _numUsers;
    string temparr[51];
    fin.open(filename);
    if (_numUsers == _sizeUser)      // checks for full array 
    {
        return -2;
    }
    if (fin.fail())                 // checks for if the file can open 
    {
        return -1; 
    }
    while (!fin.eof() && _numUsers < _sizeUser)
    {
        getline(fin, line);
        count = split(line, ',', temparr, 51);
        if(line.length() >= 1 && !isspace(line[0]))             // goes through and this loop stores the users ratings 
        {
            if ( count > 0 && count <= 51)
            {
                userArr[userCount].setNumRatings(count - 1);      // sets the rating in the arrays
                userArr[userCount].setUsername(temparr[0]);
                for (int i = 0; i < count - 1; i++)
                {
                    userArr[userCount].setRatingAt(i, stoi(temparr[i+1]));        // stores the rating 
                }
                userCount++;
                _numUsers++;       // count variables to keep track 
        
            }
        }
    }
    return userCount;
}


// gets the rating a user gave for a movie 
int Blockbustr::getRating( string username, string title)
{
    bool title1 = false; 
    bool userName1 = false;
    string tempUser; 
    string strUser;
    string tempTit; 
    string tempMo;
    int var1 = 0;
    int var2 = 0;
    
    for (int i = 0; i < _numUsers; i++ )
    {
        strUser = ToLower(userArr[i].getUsername());
        tempUser = ToLower(username);                  // checks that the user exists in the array 
        if (strUser == tempUser)
        {
            var1 = i;
            userName1 = true;
        }
    }

    for (int i = 0; i < _numMovies; i++)     // checks that the title exists in the arrray 
    {
        tempMo = ToLower(movieArr[i].getTitle());
        tempTit = ToLower(title);
        if ( tempTit == tempMo)
        {
            var2 = i;
            title1 = true;
        }
    }
    if ( title1 == true && userName1 == true)
    {
        return userArr[var1].getRatingAt(var2);       // returns the value of the users rating from the arrays 
    }
    else 
    {
        return -3; 
    }
}

// returns the number of movies watched/rated by a specific user 
int Blockbustr::getCountWatchedMovies(string username)
{
    string tempC;
    string tempS;
    int movierated = 0;
    if (_numMovies == 0)
    {
        return -3;   // checking for if their are movies to be looked at 
    }
    for (int i = 0; i < _numUsers; i++ )
    {
        tempC = ToLower(username);
        tempS = ToLower(userArr[i].getUsername());  // converts the username and title to lowercase for case insesitivity 
        if (tempC == tempS)
        {
            for ( int j = 0; j < _numMovies; j++ )
            {
                if( userArr[i].getRatingAt(j) != 0 )
                {
                    movierated++;   // counts the amount of user rated movies 
                }
            }
        return movierated;
        }
    } 
    return -3;   

}

// calcs the average rating for a movie 
double Blockbustr::calcAvgRating(string title)
{
    double count = 0.00; 
    double total = 0.00;
    if ( _numUsers == 0.00)     // checks for if users array exists 
    {
        return -3;
    } 
    for( int i = 0; i < _numUsers; i++)
    {  
        double rate = getRating(userArr[i].getUsername(), title);      // gets rating if no rating exist function stops 
        if ( rate == -3)
        {
            return -3;
        }
        if (rate > 0)       // adds up ratings 
        {
            total += rate;
            count++;            // total ratings count 
        }
    }
    if ( count == 0 )
    {
        return 0;
    }
    return (total / count);         // returns avg rating as a double 
}

// adds a new user to the system 
int Blockbustr::addUser(string username)
{
    int count = 0;
    if ( _numUsers == _sizeUser)        // checks for if arrays are correct 
    {
        return -2; 
    }
    string tempuser = ToLower(username);        // turns inputs case insensitive 
    for(int i = 0; i < _numUsers; i++)
    {
        if (userArr[i].getUsername() == tempuser)       // checks for if usrname already exists 
        {
            return 0; 
        }
    }
    userArr[_numUsers].setUsername(username);       // adds new user 
    count++;
    _numUsers++;            // correcrts the new user count 
    return count; 
} 

// user can rent a new movier and add a new ratingn 
int Blockbustr::rentMovie(string username, string title, int rating)
{
    int indexTit = -1;
    int indexUser = -1;  
    if (rating != 0 && rating != 1 &&rating != 2 &&rating != 3 &&rating != 4 &&rating != 5 )        // checks for valid rating 
    {
        return -4;
    }
    for( int i = 0; i < _numUsers; i++)
    {
        if (userArr[i].getUsername() == username)           // checks if user exists 
        {
            indexUser = i;
            break;
        }
    }
    if ( indexUser < 0 )
    {
        return -3;
    }
    for( int j = 0; j < _numMovies; j++)            // checks if movie exists 
    {
        if (movieArr[j].getTitle() == title)
        {
            indexTit = j;
            break; 
        }
    }
    if (indexTit < 0 )      
    {
        return -3;
    }
    userArr[indexUser].setRatingAt(indexTit, rating);       //sets new rating for user 
    return 1;
}