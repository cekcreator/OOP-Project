//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 problem 4

#include <iostream>
#include <fstream>
#ifndef USER_H
#define USER_H
using namespace std;

class User
{
    public:         // public class 
        User();
        User(string username, int arr[], int numRatings);   // default and parameterized constructor  
        //setters 
        void setUsername(string username);      // seeting the username 
        bool setRatingAt(int index, int value); // dcreating the set ratings function 
        void setNumRatings( int numRatings);        // number of ratings 
        //getters
        string getUsername();               // these getters acces what the setters did 
        int getRatingAt(int index);
        int getNumRatings();
        int getSize();

    private:                                // private classs of objects that are stable 
        string _username;
        const int size = 50;
        int _ratings[50];
        int _numRatings;


};
#endif