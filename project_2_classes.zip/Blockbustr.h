//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 problem 1

#include <iostream>
#include <fstream>
#include "Movie.h"
#include "User.h"
#ifndef BLOCKBUSTR_H
#define BLOCKBUSTR_H
using namespace std;


class Blockbustr
{
    public:
        //constructors 
        Blockbustr();
        //getters 
        // functions for getting movies, ratings, users, adding users and adding new ratings
        int getSizeMovie();
        int getSizeUser();
        int getNumMovies(); 
        int getNumUsers();
        int readMovies(string ); 
        void printMoviesByYear(string);
        int readRatings(string);
        int getRating(string, string);
        int getCountWatchedMovies(string ); 
        double calcAvgRating(string);
        int addUser(string );
        int rentMovie(string, string, int );
        

        // private members for number of movies and users along with their arrays 
    private:
        const int _sizeMovie = 50;
        const int _sizeUser = 100; 
        int _numMovies = 0;
        int _numUsers = 0;
        Movie movieArr[50];
        User userArr[100];
};
#endif