//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 pt1 problem 4

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include "Movie.h"
#include "User.h"

using namespace std; 

User::User()        // default construcotr checking and initialzing 
{
    _username = "";
    _numRatings = 0;
    for (int i = 0; i < size; i++)
    {
        _ratings[i] = 0;
    }
}

User::User(string username, int arr[], int numRatings)  // parameterized construcotr  settig up the multiple passing arguemtns stuff
{
    _username = username;
    for (int j = numRatings; j < size; j++)
    {
        _ratings[j] = 0;
    }
    for (int i = 0; i < numRatings; i++)        // initalizes the array correctly for each separated part 
    {
        _ratings[i] = arr[i];
    }
    _numRatings = numRatings;
}
// retruns the username 
string User::getUsername()
{
    return _username;
}
// reutrns the number of rating s
int User::getNumRatings()
{
    return _numRatings;
}
// returns the size of the array
int User::getSize()
{
    return size; 
}
// returns the rating index
int User::getRatingAt(int index)
{
    if (index < size || index < 0 )
    {
        return _ratings[index];         // validates the correct number for ratings array 
    }
    else 
    {
        return -1;
    }
}
// initialize set rating 
bool User::setRatingAt(int index, int value)
{
    if (index >= size)
    {
        return false;
    }
    else if ( value < 0 || value > 5)       // checks for valid ratinng 
    {
        return false;
    }
    _ratings[index] = value;
    return true;
    
}
//intializes the set username 
void User::setUsername(string username)
{
    _username = username;
}
// insitalies the set num ratings 
void User::setNumRatings(int numRatings)
{
    _numRatings = numRatings;
}






