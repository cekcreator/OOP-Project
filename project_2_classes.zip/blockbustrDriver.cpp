//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 problem 1

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include "BlockBustr.h"

using namespace std;

// checks to make sure rounding for doubles calc is even and set for all calcs
bool doubles_equal(double a, double b, const double epsilon = 1e-2)
{
    double c = a - b;
    return c < epsilon && -c < epsilon;
}


int main()
{
    // Can you make an instance of Blockbustr?
    Blockbustr b;
    cout << "success" << endl;

    // check if all members are initialized
    Blockbustr a;
    cout << "numMovies = " << a.getNumMovies() << endl;
    cout << "numUsers = " << a.getNumUsers() << endl;
    cout << "movie arr size = " << a.getSizeMovie() << endl;
    cout << "user arr size = " << a.getSizeUser() << endl;  
    // all memebers are initialized correctly 

    	
    // multiple text files to Blockbustr
    Blockbustr b2 = Blockbustr();
    int nummMovies = b2.readMovies("movies_minitest1.txt");
    nummMovies = b2.readMovies("movies_first_half.txt");
    cout << "readMovies returned: " << nummMovies << endl;
    cout << "numMovies = " << b2.getNumMovies() << endl;
    // reads in multpiple movie files and stores all the movies and the years 

    // addUser : success
    Blockbustr b6 = Blockbustr();
    int __numMovies = b6.readMovies("movies.txt");
    int __numUsers = b6.readRatings("ratings_first_half.txt");
    cout << "numUsers(before) = " << b6.getNumUsers() << endl;
    // successfully adds the user 

    // checking the num users
    int rv = b6.addUser("newUser");
    cout << "addUser returned: " << rv << endl;
    cout << "numUsers (after)= " << b6.getNumUsers() << endl;
    // verifies that numUsers works and it does 

    // check if we can find the newUser
    int count = b6.getCountWatchedMovies("newUser");
    cout << "getCountWatchedMovies returned: " << count << endl;
    // finds the user correctly and does read out their movies rated/watched 

    // GetRating case insensitive
    Blockbustr bustr = Blockbustr();
    int _numMovies = bustr.readMovies("movies.txt");
    int _numUsers = bustr.readRatings("ratings.txt");
    cout << bustr.getRating("adam", "Coco") << endl;
    cout << bustr.getRating("ADAM", "CoCo") << endl;
    cout << bustr.getRating("aDaM", "COCO") << endl;  
    // should read out adam and coco 

    	
    // calcAvgRating : average present
    Blockbustr b3 = Blockbustr();
    int movieCount = b3.readMovies("movies.txt");
    int userCount = b3.readRatings("ratings_first_half.txt");
    double avg = b3.calcAvgRating("The Prestige");
    cout << "calcAvgRating returned " << setprecision(2) << fixed << avg << endl;

    return 0;  

}