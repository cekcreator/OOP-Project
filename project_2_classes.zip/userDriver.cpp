//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 problem 4

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include <stdio.h>
#include <ctype.h>
#include "Movie.h"
#include "User.h"

using namespace std; 


int main()
{
    // all checks both constuctors and the each member function with invalid arguemtns and valid ones
    // default constructor username
    User u1 = User();
    cout << u1.getUsername() << endl;
    // default constructor (initialized to 0)
    User u2 = User();
    cout << u2.getNumRatings() << endl;
    User u3 = User();
    int nRating = 45;
    u3.setNumRatings(nRating);
    int rating = 3;
    int idx = 40;
    cout << "set/get setRatingAt(" << idx << "," << rating << ") [numRating=" << nRating  << "]" << endl;
    cout << "Setting rating at " << idx << " to " << rating << endl;
    string ratingset = u3.setRatingAt(idx,rating) ? "true": "false";
    cout << "setRatingAt(" << idx << "," << rating << ") returned: " << ratingset << endl;
    cout << "getRatingAt(" << idx << ") returned: " << u3.getRatingAt(idx) << endl; 
    return 0;
}