//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 pt1 problem 1

#include <iostream>
#include <iomanip> 
#include <cstring> 
#include <string>
#include <cctype>
#include <fstream>
#include "Movie.h"

using namespace std; 

// default constructor function "initialzing the functions"
Movie::Movie()
{
    title = "";
    releaseYear = "";
}
// parameterized constructor seeting op the argument passing part 
Movie::Movie(string _title, string _releaseYear)
{
    title = _title;
    releaseYear = _releaseYear; 
}
// returns title of moive 
string Movie::getTitle()
{
    return title;
}
// returns release year 
string Movie::getReleaseYear()
{
    return releaseYear;
}
// sets the title variable 
void Movie::setTitle(string _title)
{
    title = _title;
}
// sets the release yearvariable  
void Movie::setReleaseYear(string _releaseYear)
{
    releaseYear= _releaseYear;
}

