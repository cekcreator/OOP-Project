//CSCI 1300 spring 
//Caleb Kumar
// recitation 106 Tuhina Tripathi 
// Project 2 pt1 problem 1

#include <iostream>
#include <string>
#include "Movie.h"

using namespace std; 


int main ()
{
    // all assert statements check both the constructors and for bound cases 
    Movie Lost;
    Lost.setTitle("Lost");
    Lost.setReleaseYear("2004");
    cout << Lost.getTitle() << endl; 
    cout << Lost.getReleaseYear() << endl;
    Movie m1 = Movie();     // checks for nothing 
    cout << m1.getTitle() << endl; 
    cout << m1.getReleaseYear() << endl; 
    // should cout nothing which it does 
    Movie m2 = Movie("War", "2000");        // cheking for parameterized constructor 
    cout << m2.getTitle() << endl; 
    cout << m2.getReleaseYear() << endl; 
    return 0; 
}